mod mod_light;
use mod_light::TrafficLight;
use mod_light::Light;

mod sum;
use sum::*;

mod area;
use self::area::HasArea;

fn main() {
    let red = TrafficLight::Red;
    let green = TrafficLight::Green;
    let yellow = TrafficLight::Yellow;

    println!("If traffic light is {:?},it will {:?} seconds",red, red.time());
    println!("If traffic light is {:?},it will {:?} seconds",green, green.time());
    println!("If traffic light is {:?},it will {:?} seconds",yellow, yellow.time());

    let arr = vec![1, 2, 3, 4, 5];
    println!("array sum is {:?}",sum_integer_sets(&arr));

    let s = area::Square {side: 10};
    println!("square: {}", s.get_area());

    let r = area::Circle {radius: 2};
    println!("circle: {}", r.get_area());

    let t = area::Triangle {base: 2, hight: 1};
    println!("Triangle: {}", t.get_area());
}
