#[derive(Debug)]
pub enum TrafficLight {
    Red,
    Green,
    Yellow,
}

pub trait Light {
    fn time(&self) -> i32;
}

impl Light for TrafficLight{
    fn time(&self) -> i32 {
        return match self {
            TrafficLight::Red => 30,
            TrafficLight::Yellow => 5,
            TrafficLight::Green => 45,
        }
    }
}
